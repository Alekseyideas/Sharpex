<?php include (dirname(__FILE__).'/parts/header.php'); ?>
<section class="crumbs">
    <div class="container">
        <div class="row">
            <div class="col-xs-12">
                <div class="flex-row flex-a-bottom flex-j-between">
                    <h1 class="position">Payment and delivery</h1>
                    <div class="pull-right hidden-xs link-crumbs">
                        <a href="/">main</a>
                        <a href="#">Payment and delivery</a>
                    </div>
                </div>
            </div>
        </div>
    </div>
</section>


<section class="indention payment-delivery">
    <div class="container">
        <div class="row">
            <div class="col-md-6">
                <p>
                    <b>Lorem ipsum dolor sit amet,</b><br>
                    Lorem ipsum dolor sit amet, consectetur adipisicing elit. <br>
                    Aperiam consectetur consequatur cumque cupiditate dicta <br>
                    ex itaque laboriosam possimus, quae recusandae sint temporibus? Animi aspernatur distinctio<br>
                    error, odio quaerat ut veritatis?<br>
                    Lorem ipsum dolor sit amet, consectetur adipisicing elit.  Aperiam consectetur consequatur cumque cupiditate dicta <br>
                    ex itaque laboriosam possimus, quae recusandae sint temporibus? Animi aspernatur distinctio error, odio quaerat ut veritatis? <br><br>
                    <b>Lorem ipsum dolor sit amet,</b><br>
                    Lorem ipsum dolor sit amet, consectetur adipisicing elit. <br>
                    Aperiam consectetur consequatur cumque cupiditate dicta <br>
                    ex itaque laboriosam possimus, quae recusandae sint temporibus? Animi aspernatur distinctio<br>
                    error, odio quaerat ut veritatis?<br>
                    Lorem ipsum dolor sit amet, consectetur adipisicing elit.  Aperiam consectetur consequatur cumque cupiditate dicta <br>
                    ex itaque laboriosam possimus, quae recusandae sint temporibus? Animi aspernatur distinctio error, odio quaerat ut veritatis?
                    Lorem ipsum dolor sit amet, consectetur adipisicing elit. <br>
                    Aperiam consectetur consequatur cumque cupiditate dicta <br>
                    ex itaque laboriosam possimus, quae recusandae sint temporibus? Animi aspernatur distinctio<br>
                    error, odio quaerat ut veritatis?<br>
                    Lorem ipsum dolor sit amet, consectetur adipisicing elit.  Aperiam consectetur consequatur cumque cupiditate dicta <br>

                </p>
            </div>
            <div class="col-md-5 col-md-offset-1">
                <p><b>Payment</b></p>
                <img src="../img/visa.png" alt="">
                <img src="../img/privat.png" alt="">
                <img src="../img/liqpay.png" alt="">
                <br><br>
                <br><br>
                <p><b>Delivery</b></p>
                <img src="../img/nova-poshta.png" alt="">
                <br><br>
                <br><br>
                <p><b>Guarantee</b></p>
                <p>
                    Lorem ipsum dolor sit amet, consectetur adipisicing elit. Cupiditate eligendi id maxime odit praesentium repellat soluta, velit! Doloremque dolorum facilis fugiat in iusto maxime obcaecati, provident quam, quisquam quod voluptate!
                </p>
            </div>
        </div>
    </div>
</section>
<div class="clearfix"></div>
<?php include (dirname(__FILE__).'/parts/footer.php'); ?>