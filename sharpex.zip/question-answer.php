<?php include (dirname(__FILE__).'/parts/header.php'); ?>
<section class="crumbs">
    <div class="container">
        <div class="row">
            <div class="col-xs-12">
                <div class="flex-row flex-a-bottom flex-j-between">
                    <h1 class="position">Question-answer</h1>
                    <div class="pull-right hidden-xs link-crumbs">
                        <a href="/">main</a>
                        <a href="#">question-answer</a>
                    </div>
                </div>
            </div>
        </div>
    </div>
</section>

<section class="question-answer indention">
    <div class="container">
        <div class="row">
            <div class="col-md-5">
                <div class="title">
                    <h3>FAQ</h3>
                </div>
                    <div class="wr-toggle">
                        <span class="question toggle-title">What is your work schedule?</span>

                        <div class="toggle-content">
                            <p>Lorem ipsum dolor sit amet, </p>
                            <p>consectetur adipisicing elit. Aperiam doloribus eius </p>
                            <p>iusto molestiae molestias quam reiciendis voluptas. Alias aperiam cupiditate ea eum hic nisi non pariatur quidem tempore voluptates! Expedita?</p>
                            <p>Lorem ipsum dolor sit amet, </p>
                            <p>consectetur adipisicing elit. Aperiam doloribus eius </p>
                            <p>iusto molestiae molestias quam reiciendis voluptas. Alias aperiam cupiditate ea eum hic nisi non pariatur quidem tempore voluptates! Expedita?</p>
                        </div>
                    </div>

                    <div class="wr-toggle">
                        <span class="question toggle-title">Consectetur adipisicing elit. Aperiam doloribus eius?</span>
                        <div class="toggle-content">
                            <p>Lorem ipsum dolor sit amet, </p>
                            <p>consectetur adipisicing elit. Aperiam doloribus eius </p>
                            <p>iusto molestiae molestias quam reiciendis voluptas. Alias aperiam cupiditate ea eum hic nisi non pariatur quidem tempore voluptates! Expedita?</p>
                            <p>Lorem ipsum dolor sit amet, </p>
                            <p>consectetur adipisicing elit. Aperiam doloribus eius </p>
                            <p>iusto molestiae molestias quam reiciendis voluptas. Alias aperiam cupiditate ea eum hic nisi non pariatur quidem tempore voluptates! Expedita?</p>
                        </div>
                    </div>

                    <div class="wr-toggle">
                        <span class="question toggle-title">Aperiam doloribus eius?</span>
                        <div class="toggle-content">
                            <p>Lorem ipsum dolor sit amet, </p>
                            <p>consectetur adipisicing elit. Aperiam doloribus eius </p>
                            <p>iusto molestiae molestias quam reiciendis voluptas. Alias aperiam cupiditate ea eum hic nisi non pariatur quidem tempore voluptates! Expedita?</p>
                            <p>Lorem ipsum dolor sit amet, </p>
                            <p>consectetur adipisicing elit. Aperiam doloribus eius </p>
                            <p>iusto molestiae molestias quam reiciendis voluptas. Alias aperiam cupiditate ea eum hic nisi non pariatur quidem tempore voluptates! Expedita?</p>
                        </div>
                    </div>


                    <div class="wr-toggle">
                        <span class="question toggle-title">iusto molestiae molestias quam reiciendis voluptas. Alias aperiam cupiditate ea eum hic nisi non pariatur quidem tempore voluptates! Expedita?</span>
                        <div class="toggle-content">
                            <p>Lorem ipsum dolor sit amet, </p>
                            <p>consectetur adipisicing elit. Aperiam doloribus eius </p>
                            <p>iusto molestiae molestias quam reiciendis voluptas. Alias aperiam cupiditate ea eum hic nisi non pariatur quidem tempore voluptates! Expedita?</p>
                            <p>Lorem ipsum dolor sit amet, </p>
                            <p>consectetur adipisicing elit. Aperiam doloribus eius </p>
                            <p>iusto molestiae molestias quam reiciendis voluptas. Alias aperiam cupiditate ea eum hic nisi non pariatur quidem tempore voluptates! Expedita?</p>
                        </div>
                    </div>
                    <div class="wr-toggle">
                        <span class="question toggle-title">What is your work schedule?</span>

                        <div class="toggle-content">
                            <p>Lorem ipsum dolor sit amet, </p>
                            <p>consectetur adipisicing elit. Aperiam doloribus eius </p>
                            <p>iusto molestiae molestias quam reiciendis voluptas. Alias aperiam cupiditate ea eum hic nisi non pariatur quidem tempore voluptates! Expedita?</p>
                            <p>Lorem ipsum dolor sit amet, </p>
                            <p>consectetur adipisicing elit. Aperiam doloribus eius </p>
                            <p>iusto molestiae molestias quam reiciendis voluptas. Alias aperiam cupiditate ea eum hic nisi non pariatur quidem tempore voluptates! Expedita?</p>
                        </div>
                    </div>

                    <div class="wr-toggle">
                        <span class="question toggle-title">Consectetur adipisicing elit. Aperiam doloribus eius?</span>
                        <div class="toggle-content">
                            <p>Lorem ipsum dolor sit amet, </p>
                            <p>consectetur adipisicing elit. Aperiam doloribus eius </p>
                            <p>iusto molestiae molestias quam reiciendis voluptas. Alias aperiam cupiditate ea eum hic nisi non pariatur quidem tempore voluptates! Expedita?</p>
                            <p>Lorem ipsum dolor sit amet, </p>
                            <p>consectetur adipisicing elit. Aperiam doloribus eius </p>
                            <p>iusto molestiae molestias quam reiciendis voluptas. Alias aperiam cupiditate ea eum hic nisi non pariatur quidem tempore voluptates! Expedita?</p>
                        </div>
                    </div>

                    <div class="wr-toggle">
                        <span class="question toggle-title">Aperiam doloribus eius?</span>
                        <div class="toggle-content">
                            <p>Lorem ipsum dolor sit amet, </p>
                            <p>consectetur adipisicing elit. Aperiam doloribus eius </p>
                            <p>iusto molestiae molestias quam reiciendis voluptas. Alias aperiam cupiditate ea eum hic nisi non pariatur quidem tempore voluptates! Expedita?</p>
                            <p>Lorem ipsum dolor sit amet, </p>
                            <p>consectetur adipisicing elit. Aperiam doloribus eius </p>
                            <p>iusto molestiae molestias quam reiciendis voluptas. Alias aperiam cupiditate ea eum hic nisi non pariatur quidem tempore voluptates! Expedita?</p>
                        </div>
                    </div>


                    <div class="wr-toggle">
                        <span class="question toggle-title">iusto molestiae molestias quam reiciendis voluptas. Alias aperiam cupiditate ea eum hic nisi non pariatur quidem tempore voluptates! Expedita?</span>
                        <div class="toggle-content">
                            <p>Lorem ipsum dolor sit amet, </p>
                            <p>consectetur adipisicing elit. Aperiam doloribus eius </p>
                            <p>iusto molestiae molestias quam reiciendis voluptas. Alias aperiam cupiditate ea eum hic nisi non pariatur quidem tempore voluptates! Expedita?</p>
                            <p>Lorem ipsum dolor sit amet, </p>
                            <p>consectetur adipisicing elit. Aperiam doloribus eius </p>
                            <p>iusto molestiae molestias quam reiciendis voluptas. Alias aperiam cupiditate ea eum hic nisi non pariatur quidem tempore voluptates! Expedita?</p>
                        </div>
                    </div>


            </div>
            <div class="col-md-5 col-md-offset-1">
                <div class="title">
                    <h3>Payment and delivery</h3>

                </div>
                    <div class="wr-toggle">
                        <span class="question toggle-title">What is your work schedule?</span>

                        <div class="toggle-content">
                            <p>Lorem ipsum dolor sit amet, </p>
                            <p>consectetur adipisicing elit. Aperiam doloribus eius </p>
                            <p>iusto molestiae molestias quam reiciendis voluptas. Alias aperiam cupiditate ea eum hic nisi non pariatur quidem tempore voluptates! Expedita?</p>
                            <p>Lorem ipsum dolor sit amet, </p>
                            <p>consectetur adipisicing elit. Aperiam doloribus eius </p>
                            <p>iusto molestiae molestias quam reiciendis voluptas. Alias aperiam cupiditate ea eum hic nisi non pariatur quidem tempore voluptates! Expedita?</p>
                        </div>
                    </div>

                    <div class="wr-toggle">
                        <span class="question toggle-title">Consectetur adipisicing elit. Aperiam doloribus eius?</span>
                        <div class="toggle-content">
                            <p>Lorem ipsum dolor sit amet, </p>
                            <p>consectetur adipisicing elit. Aperiam doloribus eius </p>
                            <p>iusto molestiae molestias quam reiciendis voluptas. Alias aperiam cupiditate ea eum hic nisi non pariatur quidem tempore voluptates! Expedita?</p>
                            <p>Lorem ipsum dolor sit amet, </p>
                            <p>consectetur adipisicing elit. Aperiam doloribus eius </p>
                            <p>iusto molestiae molestias quam reiciendis voluptas. Alias aperiam cupiditate ea eum hic nisi non pariatur quidem tempore voluptates! Expedita?</p>
                        </div>
                    </div>

                    <div class="wr-toggle">
                        <span class="question toggle-title">Aperiam doloribus eius?</span>
                        <div class="toggle-content">
                            <p>Lorem ipsum dolor sit amet, </p>
                            <p>consectetur adipisicing elit. Aperiam doloribus eius </p>
                            <p>iusto molestiae molestias quam reiciendis voluptas. Alias aperiam cupiditate ea eum hic nisi non pariatur quidem tempore voluptates! Expedita?</p>
                            <p>Lorem ipsum dolor sit amet, </p>
                            <p>consectetur adipisicing elit. Aperiam doloribus eius </p>
                            <p>iusto molestiae molestias quam reiciendis voluptas. Alias aperiam cupiditate ea eum hic nisi non pariatur quidem tempore voluptates! Expedita?</p>
                        </div>
                    </div>


                    <div class="wr-toggle">
                        <span class="question toggle-title">iusto molestiae molestias quam reiciendis voluptas. Alias aperiam cupiditate ea eum hic nisi non pariatur quidem tempore voluptates! Expedita?</span>
                        <div class="toggle-content">
                            <p>Lorem ipsum dolor sit amet, </p>
                            <p>consectetur adipisicing elit. Aperiam doloribus eius </p>
                            <p>iusto molestiae molestias quam reiciendis voluptas. Alias aperiam cupiditate ea eum hic nisi non pariatur quidem tempore voluptates! Expedita?</p>
                            <p>Lorem ipsum dolor sit amet, </p>
                            <p>consectetur adipisicing elit. Aperiam doloribus eius </p>
                            <p>iusto molestiae molestias quam reiciendis voluptas. Alias aperiam cupiditate ea eum hic nisi non pariatur quidem tempore voluptates! Expedita?</p>
                        </div>
                    </div>
                    <div class="wr-toggle">
                        <span class="question toggle-title">What is your work schedule?</span>

                        <div class="toggle-content">
                            <p>Lorem ipsum dolor sit amet, </p>
                            <p>consectetur adipisicing elit. Aperiam doloribus eius </p>
                            <p>iusto molestiae molestias quam reiciendis voluptas. Alias aperiam cupiditate ea eum hic nisi non pariatur quidem tempore voluptates! Expedita?</p>
                            <p>Lorem ipsum dolor sit amet, </p>
                            <p>consectetur adipisicing elit. Aperiam doloribus eius </p>
                            <p>iusto molestiae molestias quam reiciendis voluptas. Alias aperiam cupiditate ea eum hic nisi non pariatur quidem tempore voluptates! Expedita?</p>
                        </div>
                    </div>

                    <div class="wr-toggle">
                        <span class="question toggle-title">Consectetur adipisicing elit. Aperiam doloribus eius?</span>
                        <div class="toggle-content">
                            <p>Lorem ipsum dolor sit amet, </p>
                            <p>consectetur adipisicing elit. Aperiam doloribus eius </p>
                            <p>iusto molestiae molestias quam reiciendis voluptas. Alias aperiam cupiditate ea eum hic nisi non pariatur quidem tempore voluptates! Expedita?</p>
                            <p>Lorem ipsum dolor sit amet, </p>
                            <p>consectetur adipisicing elit. Aperiam doloribus eius </p>
                            <p>iusto molestiae molestias quam reiciendis voluptas. Alias aperiam cupiditate ea eum hic nisi non pariatur quidem tempore voluptates! Expedita?</p>
                        </div>
                    </div>

                    <div class="wr-toggle">
                        <span class="question toggle-title">Aperiam doloribus eius?</span>
                        <div class="toggle-content">
                            <p>Lorem ipsum dolor sit amet, </p>
                            <p>consectetur adipisicing elit. Aperiam doloribus eius </p>
                            <p>iusto molestiae molestias quam reiciendis voluptas. Alias aperiam cupiditate ea eum hic nisi non pariatur quidem tempore voluptates! Expedita?</p>
                            <p>Lorem ipsum dolor sit amet, </p>
                            <p>consectetur adipisicing elit. Aperiam doloribus eius </p>
                            <p>iusto molestiae molestias quam reiciendis voluptas. Alias aperiam cupiditate ea eum hic nisi non pariatur quidem tempore voluptates! Expedita?</p>
                        </div>
                    </div>


                    <div class="wr-toggle">
                        <span class="question toggle-title">iusto molestiae molestias quam reiciendis voluptas. Alias aperiam cupiditate ea eum hic nisi non pariatur quidem tempore voluptates! Expedita?</span>
                        <div class="toggle-content">
                            <p>Lorem ipsum dolor sit amet, </p>
                            <p>consectetur adipisicing elit. Aperiam doloribus eius </p>
                            <p>iusto molestiae molestias quam reiciendis voluptas. Alias aperiam cupiditate ea eum hic nisi non pariatur quidem tempore voluptates! Expedita?</p>
                            <p>Lorem ipsum dolor sit amet, </p>
                            <p>consectetur adipisicing elit. Aperiam doloribus eius </p>
                            <p>iusto molestiae molestias quam reiciendis voluptas. Alias aperiam cupiditate ea eum hic nisi non pariatur quidem tempore voluptates! Expedita?</p>
                        </div>
                    </div>
                    <div class="wr-toggle">
                        <span class="question toggle-title">What is your work schedule?</span>

                        <div class="toggle-content">
                            <p>Lorem ipsum dolor sit amet, </p>
                            <p>consectetur adipisicing elit. Aperiam doloribus eius </p>
                            <p>iusto molestiae molestias quam reiciendis voluptas. Alias aperiam cupiditate ea eum hic nisi non pariatur quidem tempore voluptates! Expedita?</p>
                            <p>Lorem ipsum dolor sit amet, </p>
                            <p>consectetur adipisicing elit. Aperiam doloribus eius </p>
                            <p>iusto molestiae molestias quam reiciendis voluptas. Alias aperiam cupiditate ea eum hic nisi non pariatur quidem tempore voluptates! Expedita?</p>
                        </div>
                    </div>



            </div>

        </div>
    </div>
</section>
    <div class="clearfix"></div>
<?php include (dirname(__FILE__).'/parts/footer.php'); ?>